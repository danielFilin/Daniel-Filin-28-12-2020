module.exports = {
  secretOrKey: 'verysedsvsdvsdsdsdcretstring',
  mongoDB: 'DcjKBqPywLMsaB2'
}
 